#include <avr/io.h>
#include "Arduino.h"

#include <avr/interrupt.h>
#include <stdio.h>

#include "I2C.h"
#include "switch.h"
#include "timer.h"
#include "lcd.h"
#include "pwm.h"


#define TEMPMEASURE 0xE3
#define HUMIDMEASURE 0xE5
#define SOFT_RESET 0xFE

#define SLA 0x40
#define Th_Temp 30
#define Th_humid 95
enum motor{off, on};

volatile motor state2 = off;

 enum buttonstate{
waitpress,//wait press
dbpress,//debounce press
waitrelse,//wait release
dbrelse,//debounce release
} ;

volatile buttonstate state = waitpress; //// default state

int main(){
  Serial.begin(9600); // using serial port to print values from I2C bus

  initSwitchPB3();//initializes PB3
  initTimer0();//initializes timer0
  initTimer1();//initializes timer1
  initLCD(); //initializes LCD
  initI2C();  // initialize I2C and set bit rate
  sei(); // Enable global interrupts.
  moveCursor(0, 0); // moves the cursor to 0,0 position
  writeString("Temp: ");
  moveCursor(1, 0);  // moves the cursor to 1,0 position
  writeString("RH: ");

  startI2C_Trans(SLA);
  write(SOFT_RESET); //implementing a soft reset before taking any readings from the sensor
  stopI2C_Trans();

  unsigned int tempReading;
  unsigned int humidReading;
  float tempOut;
  float humidOut;
  char tempPrint[6];
  char humidPrint[6];

  initPWMTimer3();

  bool offOverride = false; //override the temperature's off to turn on
  bool onOverride = false; //override the tempersture's on to turn it off

  Serial.println("initdone");

  while(1){

    switch(state){
case waitpress:
break;
case dbpress:
delayMs(5);
state = waitrelse;
break;
case waitrelse:
break;
case dbrelse:
if(state2 == on) {
  onOverride = !onOverride;
}
else {
  offOverride = !offOverride;
}
delayMs(5);
state = waitpress;
break;
}


   delayMs(1000);
  // Serial.print("onOverride: ");
  // Serial.println(onOverride);
  // Serial.print("offOverride: ");
  // Serial.println(offOverride);


    if(state2 ==  on){
      if(!onOverride) {
        L293D_clockwise();
      }
      else {
        STOP_motor();
      }
      offOverride = false; //resets the opposite override to the current state
    }
    else if(state2 == off){
      if(!offOverride) {
        STOP_motor();
      }
      else {
        L293D_clockwise();
      }
      onOverride = false; //resets the opposite override to the current state
    }


  
    tempReading = HoldCommunication(SLA, TEMPMEASURE);/////////////////////////////////////////////////////
    Serial.println("tempread");
    tempReading = (tempReading & 0xFFFC);
    //Serial.println(tempReading, HEX);

    //tempOut = 175.72 * (float(tempReading)/(65536.0)) - 46.85;
    tempOut = ((((float)tempReading)/(65536.0)) * 175.72) - 46.85;
    
    dtostrf(tempOut, 4, 2, tempPrint);
    moveCursor(0,6);
    writeString(tempPrint);

    humidReading = HoldCommunication(SLA, HUMIDMEASURE);///////////////////////////////////////////////////////
    Serial.println("humidityread");
    humidReading = (humidReading & 0xFFFC);
    //Serial.println(humidReading, HEX);

    humidOut = ((((float)humidReading)/(65536.0)) * 125.0) - 6.0;
    //Serial.println(humidOut);
    
    dtostrf(humidOut, 4, 2, humidPrint);
    moveCursor(1,4);
    writeString(humidPrint);

    if(tempOut > Th_Temp && humidOut < Th_humid){
      state2 = on;
    }
    else {
      state2 = off;
    }
    


  }

  return 0;
}

ISR(PCINT0_vect){// PCINT0_vect This name is found by reading the datasheet (Vector table page 101)
if (state == waitpress){
  //Serial.println("int");
  state = dbpress;
}
else if (state == waitrelse){
  //Serial.println("int");
  state = dbrelse;
// if (state2 == off){
//   state2 = on;
// }
// else if (state2 == on){
//   state2 = off;
// }
}
}

