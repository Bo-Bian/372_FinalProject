// Author:   Jaime Valencia, Ian Johnson, Osman Syed, Ritik Makhija
// Net ID:
// Date:          5/11/23
// Assignment:     Final Project
#ifndef TIMER_H
#define TIMER_H

#include <avr/io.h>

void initTimer1();
void delayUs(unsigned int delay);
void initTimer0();
void delayMs(unsigned int delay); 

#endif