

#include <Arduino.h>
#include <avr/io.h>
#include "switch.h"
#include "timer.h"
#include <avr/interrupt.h>
#include "lcd.h"




enum temp{cold, hot};

volatile temp state2 = cold;

 enum buttonstate{
waitpress,//wait press
dbpress,//debounce press
waitrelse,//wait release
dbrelse,//debounce release
} ;


volatile buttonstate state = waitpress; //volatile variable set as initial state



int main(){
  Serial.begin(9600);
 //unsigned char num = 0;
 int temp = 100;


initSwitchPB3();//initializes PB3
 initTimer0();//initializes timer0
  initTimer1();//initializes timer1
  initLCD(); //initializes LCD
  sei(); // Enable global interrupts.
moveCursor(0, 0); // moves the cursor to 0,0 position
 writeString("Temp: ");
moveCursor(1, 0);  // moves the cursor to 1,0 position
  writeString("RH: ");
  
  


// Implement a state machine in the while loop which achieves the assignment requirements.
  
	while(1){

switch(state){
case waitpress:
break;
case dbpress:
delayMs(1);
state = waitrelse;
break;
case waitrelse:
break;
case dbrelse:
delayMs(1);
state = waitpress;
break;
}

    
    
    for (int i = 0; i < 16; i++){ 
     // num = 0;
      
     
      
      if (state2 == hot){
       temp = 100;
        moveCursor(1, 0);  // moves the cursor to 1,0 position
        //writeString("Temperature: ");
        //writeString("Relative Humidity: "); //Fix me
      }
      else if (state2 == cold){
        temp = 50;
         moveCursor(1, 0);  // moves the cursor to 1,0 position
        //writeString("Temperature: ");
       // writeString("Relative Humidity:"); 
       
      }
      
      //delayMs(time);
    //_delay_ms (LONG_DELAY);
    }
    
    

  }
  Serial.println ("I am still here");
  Serial.flush();
  return 0;
}


ISR(PCINT0_vect){// PCINT0_vect This name is found by reading the datasheet (Vector table page 101)
if (state == waitpress){
  state = dbpress;
}

if (state == waitrelse){
  state = dbrelse;
if (state2 == hot){
  state2 = cold;
}
else if (state2 == hot){
  state2 = cold;
}
}
}